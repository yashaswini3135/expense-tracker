# Spendly — Expense Tracker

A responsive, browser-based Expense Tracker built with HTML, CSS and vanilla JavaScript.

## Features
- Dashboard showing total expenses, current-month spending, transaction count and average expense.
- Add, edit and delete expense records.
- Expense categories and custom category management.
- Search, category filtering and sorting.
- Donut chart showing category-wise spending (drawn with the HTML Canvas API).
- Export transactions as CSV.
- Automatically saves expenses and categories in browser LocalStorage.
- Responsive layout for laptop, tablet and mobile screens.

## Project files
- `index.html` — page structure and forms
- `style.css` — responsive modern dashboard styling
- `app.js` — expense logic, chart, filters and LocalStorage

## Run the project
1. Download and extract `expense-tracker.zip`.
2. Open the extracted `expense-tracker` folder.
3. Double-click `index.html`.
4. The project opens in your default browser. No installation or server is required.
5. Click **Add expense** to record your first transaction.

Recommended: use the latest version of Chrome, Edge, Firefox or Safari.

## Data storage
Records are stored locally in the browser using LocalStorage. They remain available in the same browser on the same device. Clearing browser site data or using a different browser/device can remove or hide the records. Export a CSV backup regularly.

## Notes
- The currency is set to Indian Rupees (INR). To change it, update the `money()` function in `app.js`.
- The page uses Google Fonts when an internet connection is available; system fonts will be used if offline.
- This is a front-end college project. It does not include user login, cloud sync or a server/database.
