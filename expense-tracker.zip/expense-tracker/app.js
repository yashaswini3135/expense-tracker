const DEFAULT_CATEGORIES = ["Food", "Travel", "Shopping", "Bills", "Health", "Entertainment", "Education", "Other"];
const CATEGORY_COLORS = ["#8069ed", "#36b995", "#f0a04d", "#5595df", "#e8799c", "#43b8c8", "#9b82df", "#9aa5b5"];
const CATEGORY_ICONS = {Food:"🍽",Travel:"🚕",Shopping:"🛍",Bills:"🧾",Health:"💊",Entertainment:"🎬",Education:"📚",Other:"✦"};
const STORAGE_KEYS = {expenses:"spendly_expenses_v1",categories:"spendly_categories_v1"};
let expenses = load(STORAGE_KEYS.expenses, []);
let categories = load(STORAGE_KEYS.categories, DEFAULT_CATEGORIES);
let toastTimer;

const $ = id => document.getElementById(id);
const money = value => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(Number(value)||0);
const dateOnly = value => new Date(value + "T00:00:00");
const prettyDate = value => dateOnly(value).toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"});
function load(key,fallback){try{const value=JSON.parse(localStorage.getItem(key));return value??fallback}catch{return fallback}}
function save(){localStorage.setItem(STORAGE_KEYS.expenses,JSON.stringify(expenses));localStorage.setItem(STORAGE_KEYS.categories,JSON.stringify(categories))}
function todayISO(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
function currentMonthItems(){const now=new Date();return expenses.filter(e=>{const d=dateOnly(e.date);return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear()})}
function showToast(message){const toast=$("toast");toast.textContent=message;toast.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove("show"),2600)}
function categoryColor(category){const i=Math.max(0,categories.indexOf(category));return CATEGORY_COLORS[i%CATEGORY_COLORS.length]}
function categoryIcon(category){return CATEGORY_ICONS[category]||"✦"}

function render(){
  renderSummary();renderChart();renderInsights();renderTransactions();renderCategoryControls();renderCategories();
}
function renderSummary(){
  const total=expenses.reduce((sum,e)=>sum+Number(e.amount),0);
  const month=currentMonthItems().reduce((sum,e)=>sum+Number(e.amount),0);
  $("totalAmount").textContent=money(total);$("monthAmount").textContent=money(month);
  $("transactionCount").textContent=expenses.length.toLocaleString("en-IN");
  $("averageAmount").textContent=money(expenses.length?total/expenses.length:0);
}
function getChartItems(){
  const items=$("chartPeriod").value==="month"?currentMonthItems():expenses;
  const totals={};items.forEach(e=>totals[e.category]=(totals[e.category]||0)+Number(e.amount));
  return Object.entries(totals).sort((a,b)=>b[1]-a[1]);
}
function renderChart(){
  const canvas=$("expenseChart"),ctx=canvas.getContext("2d"),data=getChartItems();
  const total=data.reduce((s,item)=>s+item[1],0);
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const cx=130,cy=130,r=99,line=27;let angle=-Math.PI/2;
  if(!data.length){ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.strokeStyle="#f0f1f6";ctx.lineWidth=line;ctx.stroke()}
  data.forEach(([name,value])=>{const sweep=value/total*Math.PI*2;ctx.beginPath();ctx.arc(cx,cy,r,angle,angle+sweep);ctx.strokeStyle=categoryColor(name);ctx.lineWidth=line;ctx.lineCap="butt";ctx.stroke();angle+=sweep});
  $("chartTotal").textContent=total>=100000?`₹${(total/100000).toFixed(1)}L`:money(total).replace(".00","");
  $("chartLegend").innerHTML=data.length?data.map(([name,value])=>`<div class="legend-row"><span class="legend-color" style="background:${categoryColor(name)}"></span><span>${escapeHTML(name)}</span><strong>${Math.round(value/total*100)}%</strong></div>`).join(""):'<div class="empty-chart">Add expenses to see your breakdown.</div>';
}
function renderInsights(){
  const data=getChartItems();
  $("topCategory").textContent=data.length?`${data[0][0]} · ${money(data[0][1])}`:"No data yet";
  const latest=[...expenses].sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt-a.createdAt)[0];
  $("recentExpense").textContent=latest?`${latest.title} · ${money(latest.amount)}`:"No transactions yet";
  $("insightMessage").textContent=data.length?`${data[0][0]} is your highest spending category. Keep tracking expenses to understand your habits.`:"Start by adding your first expense. Your dashboard will update automatically.";
}
function filteredExpenses(){
  const q=$("searchInput").value.trim().toLowerCase(),category=$("categoryFilter").value,sort=$("sortFilter").value;
  let list=expenses.filter(e=>(category==="all"||e.category===category)&&(`${e.title} ${e.category} ${e.note||""}`).toLowerCase().includes(q));
  list.sort((a,b)=>sort==="oldest"?a.date.localeCompare(b.date):sort==="high"?b.amount-a.amount:sort==="low"?a.amount-b.amount:b.date.localeCompare(a.date)||b.createdAt-a.createdAt);
  return list;
}
function renderTransactions(){
  const list=filteredExpenses(),tbody=$("transactionRows");
  tbody.innerHTML=list.map(e=>`<tr>
    <td><div class="expense-name"><span class="expense-avatar">${categoryIcon(e.category)}</span><span>${escapeHTML(e.title)}${e.note?`<small class="expense-note">${escapeHTML(e.note)}</small>`:""}</span></div></td>
    <td><span class="category-pill">${escapeHTML(e.category)}</span></td><td>${prettyDate(e.date)}</td>
    <td class="amount-cell">${money(e.amount)}</td>
    <td class="row-actions"><button class="icon-btn" title="Edit expense" aria-label="Edit ${escapeHTML(e.title)}" data-action="edit" data-id="${e.id}">✎</button><button class="icon-btn" title="Delete expense" aria-label="Delete ${escapeHTML(e.title)}" data-action="delete" data-id="${e.id}">×</button></td>
  </tr>`).join("");
  $("emptyState").classList.toggle("show",list.length===0);
  $("transactionRows").parentElement.style.display=list.length?"table":"none";
}
function renderCategoryControls(){
  const selected=$("expenseCategory").value;
  $("expenseCategory").innerHTML=categories.map(c=>`<option value="${escapeAttr(c)}">${escapeHTML(c)}</option>`).join("");
  if(categories.includes(selected))$("expenseCategory").value=selected;
  const filter=$("categoryFilter").value;
  $("categoryFilter").innerHTML='<option value="all">All categories</option>'+categories.map(c=>`<option value="${escapeAttr(c)}">${escapeHTML(c)}</option>`).join("");
  if(categories.includes(filter))$("categoryFilter").value=filter;
}
function renderCategories(){
  $("categoryList").innerHTML=categories.map(c=>`<span class="category-chip"><span class="category-dot" style="background:${categoryColor(c)}"></span>${escapeHTML(c)}${DEFAULT_CATEGORIES.includes(c)?"":`<button type="button" title="Delete ${escapeAttr(c)} category" aria-label="Delete ${escapeAttr(c)} category" data-remove-category="${escapeAttr(c)}">×</button>`}</span>`).join("");
}
function escapeHTML(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function escapeAttr(value){return escapeHTML(value)}
function openModal(expense=null){
  $("expenseForm").reset();$("formError").textContent="";$("expenseId").value=expense?.id||"";
  $("modalTitle").textContent=expense?"Edit expense":"Add expense";
  $("saveExpenseBtn").textContent=expense?"Update expense":"Save expense";
  $("expenseTitle").value=expense?.title||"";$("expenseAmount").value=expense?.amount??"";
  $("expenseDate").value=expense?.date||todayISO();$("expenseNote").value=expense?.note||"";
  renderCategoryControls();$("expenseCategory").value=expense?.category||categories[0];
  $("expenseModal").classList.add("open");$("expenseModal").setAttribute("aria-hidden","false");
  setTimeout(()=>$("expenseTitle").focus(),50);
}
function closeModal(){$("expenseModal").classList.remove("open");$("expenseModal").setAttribute("aria-hidden","true")}
$("openAddBtn").addEventListener("click",()=>openModal());
$("emptyAddBtn").addEventListener("click",()=>openModal());
$("closeModalBtn").addEventListener("click",closeModal);
$("cancelModalBtn").addEventListener("click",closeModal);
$("expenseModal").addEventListener("click",e=>{if(e.target===$("expenseModal"))closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
$("expenseForm").addEventListener("submit",e=>{
  e.preventDefault();
  const title=$("expenseTitle").value.trim(),amount=Number($("expenseAmount").value),date=$("expenseDate").value,category=$("expenseCategory").value,note=$("expenseNote").value.trim();
  if(!title||!date||!category||!Number.isFinite(amount)||amount<=0){$("formError").textContent="Please enter a name, valid amount, date and category.";return}
  if(date>todayISO()){$("formError").textContent="Expense date cannot be in the future.";return}
  const id=$("expenseId").value;
  if(id){const i=expenses.findIndex(x=>x.id===id);if(i>=0)expenses[i]={...expenses[i],title,amount,date,category,note};showToast("Expense updated successfully")}
  else{expenses.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),title,amount,date,category,note,createdAt:Date.now()});showToast("Expense added successfully")}
  save();closeModal();render();
});
$("transactionRows").addEventListener("click",e=>{
  const btn=e.target.closest("button[data-action]");if(!btn)return;
  const item=expenses.find(x=>x.id===btn.dataset.id);if(!item)return;
  if(btn.dataset.action==="edit")openModal(item);
  if(btn.dataset.action==="delete"&&confirm(`Delete "${item.title}"? This cannot be undone.`)){expenses=expenses.filter(x=>x.id!==item.id);save();render();showToast("Expense deleted")}
});
["searchInput","categoryFilter","sortFilter"].forEach(id=>$(id).addEventListener(id==="searchInput"?"input":"change",renderTransactions));
$("chartPeriod").addEventListener("change",()=>{renderChart();renderInsights()});
$("categoryForm").addEventListener("submit",e=>{
  e.preventDefault();const name=$("newCategory").value.trim();
  if(!name)return;if(categories.some(c=>c.toLowerCase()===name.toLowerCase())){showToast("That category already exists");return}
  categories.push(name);$("newCategory").value="";save();render();showToast("Category added");
});
$("categoryList").addEventListener("click",e=>{
  const btn=e.target.closest("[data-remove-category]");if(!btn)return;
  const name=btn.dataset.removeCategory;
  if(expenses.some(x=>x.category===name)){showToast("This category is in use. Move or delete its expenses first.");return}
  if(confirm(`Delete the "${name}" category?`)){categories=categories.filter(c=>c!==name);save();render();showToast("Category removed")}
});
$("exportBtn").addEventListener("click",()=>{
  if(!expenses.length){showToast("There are no expenses to export");return}
  const rows=[["Name","Amount (INR)","Category","Date","Note"],...expenses.map(e=>[e.title,e.amount,e.category,e.date,e.note||""])];
  const csv=rows.map(row=>row.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\r\n");
  const blob=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8;"}),url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download=`spendly-expenses-${todayISO()}.csv`;a.click();URL.revokeObjectURL(url);showToast("CSV file exported");
});
$("todayLabel").textContent=new Date().toLocaleDateString("en-IN",{weekday:"short",day:"numeric",month:"short",year:"numeric"});
render();
